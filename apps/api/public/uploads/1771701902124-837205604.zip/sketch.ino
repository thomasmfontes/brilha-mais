#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "DHTesp.h" 

#define SCREEN_WIDTH 128 
#define SCREEN_HEIGHT 64 

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
DHTesp dhtSensor;

// Definição dos Pinos
const int pinoBombaN = 18; 
const int pinoBombaP = 19; 
const int pinoBombaK = 5;  
const int pinoLuzArtificial = 23; // NOVO: Grow Light
const int pinoSensorSolo = 34; 
const int pinoDHT = 14;    
const int pinoLDR = 32;    

void setup() {
  Serial.begin(115200);
  
  pinMode(pinoBombaN, OUTPUT);
  pinMode(pinoBombaP, OUTPUT);
  pinMode(pinoBombaK, OUTPUT);
  pinMode(pinoLuzArtificial, OUTPUT); // Configura o pino da luz

  dhtSensor.setup(pinoDHT, DHTesp::DHT22);

  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
    for(;;);
  }
  
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(30, 25);
  display.println("BioCore AI");
  display.display();
  delay(2000);
}

void loop() {
  int valorNPK = analogRead(pinoSensorSolo); 
  int valorLuzAmbiente = analogRead(pinoLDR); 
  int porcentagemLuz = map(valorLuzAmbiente, 0, 4095, 100, 0); // Inverte para %
  TempAndHumidity data = dhtSensor.getTempAndHumidity();
  
  int barraProgresso = map(valorNPK, 0, 4095, 0, 100);

  // LÓGICA DA LUZ ARTIFICIAL
  // Se a luz ambiente for menor que 20%, liga a Grow Light
  if (porcentagemLuz < 20) {
    digitalWrite(pinoLuzArtificial, HIGH);
  } else {
    digitalWrite(pinoLuzArtificial, LOW);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  
  // Status Ambiental no OLED
  display.setCursor(0, 0);
  display.print("T:"); display.print(data.temperature, 1); 
  display.print("C H:"); display.print(data.humidity, 0); display.print("%");
  display.setCursor(90, 0);
  display.print("L:"); display.print(porcentagemLuz); display.print("%");

  display.drawLine(0, 10, 128, 10, WHITE); 

  // Status Nutrientes
  display.setCursor(0, 18);
  display.print("NPK Solo: "); display.print(valorNPK);

  display.setCursor(0, 35);
  if (valorNPK < 1300) { 
    digitalWrite(pinoBombaN, HIGH); digitalWrite(pinoBombaP, LOW); digitalWrite(pinoBombaK, LOW);
    display.println("STATUS: INJETANDO N");
  } else if (valorNPK < 2600) {
    digitalWrite(pinoBombaN, LOW); digitalWrite(pinoBombaP, HIGH); digitalWrite(pinoBombaK, LOW);
    display.println("STATUS: INJETANDO P");
  } else if (valorNPK < 3800) {
    digitalWrite(pinoBombaN, LOW); digitalWrite(pinoBombaP, LOW); digitalWrite(pinoBombaK, HIGH);
    display.println("STATUS: INJETANDO K");
  } else {
    digitalWrite(pinoBombaN, LOW); digitalWrite(pinoBombaP, LOW); digitalWrite(pinoBombaK, LOW);
    display.println("STATUS: SAUDAVEL");
  }

  // Indicação de Luz no Display
  display.setCursor(0, 45);
  if (porcentagemLuz < 20) display.println("LUZ ARTIFICIAL: ON");

  display.drawRect(14, 55, 102, 8, WHITE);
  display.fillRect(15, 56, barraProgresso, 6, WHITE);

  display.display();
  delay(500); 
}